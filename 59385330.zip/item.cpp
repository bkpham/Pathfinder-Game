#include "item.hpp"

char Item::ICON = '$';

Item::Item(int y, int x)
    : mY(y), mX(x)
{
}
